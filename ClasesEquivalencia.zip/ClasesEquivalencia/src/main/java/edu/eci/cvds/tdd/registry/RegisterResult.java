package edu.eci.cvds.tdd.registry;

public enum RegisterResult {
        DEAD, UNDERAGE, INVALID_AGE, VALID, DUPLICATED,NO_NAME,INVALID_GENDER
}